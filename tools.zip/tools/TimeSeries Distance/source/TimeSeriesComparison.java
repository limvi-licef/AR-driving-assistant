package com.analysis;

import com.fastdtw.dtw.FastDTW;
import com.fastdtw.timeseries.TimeSeries;
import com.fastdtw.timeseries.TimeSeriesBase;
import com.fastdtw.util.Distances;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

import static com.fastdtw.timeseries.TimeSeriesBase.builder;

public class TimeSeriesComparison {

    public static void main(String[] args) {

        CommandLineParser parser = new DefaultParser();
        Options options = generateOptions();
        CommandLine parsedArgs;
        //show usage
        HelpFormatter formatter = new HelpFormatter();

        String ts1 = "";
        String ts2 = "";

        try {
            // parse the command line arguments
            parsedArgs = parser.parse( options, args );

            if( parsedArgs.hasOption( "ts1" ) ) {
                ts1 = parsedArgs.getOptionValue( "ts1" ) ;
            }

            if( parsedArgs.hasOption( "ts2" ) ) {
                ts2 = parsedArgs.getOptionValue( "ts2" ) ;
            }
        }
        catch( ParseException exp ) {
            System.out.println( "Error : Missing TimeSeries argument" );
            formatter.printHelp( "java -jar TimeSeriesDistance.jar", options );
            return;
        }

        double distance = FastDTW.compare(createTimeSeries(ts1), createTimeSeries(ts2), 10, Distances.EUCLIDEAN_DISTANCE).getDistance();

        System.out.println("Distance : " + distance);
    }

    private static TimeSeries createTimeSeries(String ts) {
        TimeSeriesBase.Builder b = builder();
        int i = 0;
        for (String data : ts.split(",")) {
            b.add(i, Double.parseDouble(data));
            i++;
        }
        return b.build();
    }

    private static Options generateOptions() {
        Options options = new Options();
        options.addOption( OptionBuilder.withLongOpt( "ts1" )
                .withDescription( "the first series, each value separated by a comma" )
                .isRequired()
                .hasArg()
                .withArgName("TIMESERIES")
                .create() );
        options.addOption( OptionBuilder.withLongOpt( "ts2" )
                .withDescription( "the second series, each value separated by a comma" )
                .isRequired()
                .hasArg()
                .withArgName("TIMESERIES")
                .create() );
        return options;
    }
}
