package com.test;

import com.fastdtw.dtw.FastDTW;
import com.fastdtw.timeseries.TimeSeries;
import com.fastdtw.timeseries.TimeSeriesBase;
import com.fastdtw.util.Distances;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

import com.test.Structs.*;

import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;

public class DTW {

    public static void dtw(String dtwPath, List<SegmentationAlgorithmReturnData> dataset, Options options, HelpFormatter formatter) {
        try {
            List<TimestampedDouble> dtwSegment = readDTW(dtwPath);
            writeDTW(dataset, dtwSegment);
        } catch (IOException e) {
            System.out.println(e.getMessage());
            formatter.printHelp( "java -jar Segmentation.jar", options );
        }
    }

    private static List<TimestampedDouble> readDTW(String dtwPath) throws IOException {
        CSVReader reader = new CSVReader(new FileReader(dtwPath));
        //String[] header = reader.readNext();
        String[] line = null;
        List<TimestampedDouble> dtwSegment = new ArrayList<>();
        while((line = reader.readNext())!= null){
            double time = Double.parseDouble(line[0]);
            double value = Double.parseDouble(line[1]);
            dtwSegment.add(new TimestampedDouble(time, value));
        }
        return dtwSegment;
    }

    private static void writeDTW(List<SegmentationAlgorithmReturnData> dataset, List<TimestampedDouble> sample) {

        CSVWriter csvWriter = null;
        try {
            csvWriter = new CSVWriter(new FileWriter("DTWValues.csv"));
            csvWriter.writeNext("Segment", "Sous-segment", "Distance");
            TimeSeries sampleSpeed = createTimeSeries(sample);

            int j = 1;
            for(SegmentationAlgorithmReturnData segment : dataset) {
                for (int i = 0; i <= segment.monotoneValues.size() - sample.size(); i++) {
                    List<TimestampedDouble> subSegment = segment.monotoneValues.subList(i, i + sample.size());
                    TimeSeries subSegmentSpeed = createTimeSeries(subSegment);
                    double distanceSpeed = FastDTW.compare(sampleSpeed, subSegmentSpeed, 10, Distances.EUCLIDEAN_DISTANCE).getDistance();

                    csvWriter.writeNext("" +  j, (i + 1) + " à " + (i + sample.size()), "" + distanceSpeed);
                }
                j++;
            }
            System.out.println("Finished DTW");
            csvWriter.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    private static TimeSeries createTimeSeries(List<TimestampedDouble> values){
        TimeSeriesBase.Builder b = TimeSeriesBase.builder();
        for (TimestampedDouble d : values) {
            b.add(d.timestamp, d.value);
        }
        return b.build();
    }
}
