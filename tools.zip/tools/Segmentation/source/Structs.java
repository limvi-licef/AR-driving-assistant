package com.test;

import java.util.List;

public class Structs {

    public static class TimestampedDouble {
        public Double timestamp;
        public Double value;

        public TimestampedDouble(Double timestamp, Double value) {
            this.timestamp = timestamp;
            this.value = value;
        }
    }

    public static class SegmentationAlgorithmReturnData {
        public ExtremaStats extremaStats;
        public List<TimestampedDouble> monotoneValues;

        public SegmentationAlgorithmReturnData(ExtremaStats extremaStats, List<TimestampedDouble> monotoneValues) {
            this.extremaStats = extremaStats;
            this.monotoneValues = monotoneValues;
        }
    }

    public static class ExtremaStats {
        public double positiveAverage;
        public double negativeAverage;
        public double positiveStandardDeviation;
        public double negativeStandardDeviation;
        public int positiveCount;
        public int negativeCount;

        public ExtremaStats(double positiveAverage, double negativeAverage, double positiveStandardDeviation, double negativeStandardDeviation, int positiveCount, int negativeCount) {
            this.positiveAverage = positiveAverage;
            this.negativeAverage = negativeAverage;
            this.positiveStandardDeviation = positiveStandardDeviation;
            this.negativeStandardDeviation = negativeStandardDeviation;
            this.positiveCount = positiveCount;
            this.negativeCount = negativeCount;
        }
    }
}
