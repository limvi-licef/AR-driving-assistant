package com.test;

import java.util.ArrayList;
import java.util.List;

import com.test.Structs.*;

class Statistics {

    private static double calculateAverage(List<Double> list) {
        if(list.isEmpty()) return 0;
        double sum = 0;
        for (Double mark : list) {
            sum += mark;
        }
        return sum / list.size();
    }

    private static double calculateStandardDeviation(List<Double> list, double average) {
        if(list.isEmpty()) return 0;
        double squaredSum = 0;
        for(Double d : list) {
            squaredSum += (d-average)*(d-average);
        }
        return Math.sqrt(squaredSum / list.size());
    }

    static ExtremaStats computeExtremaStats(List<TimestampedDouble> values, List<Integer> indexes){
        List<Double> negativeExtrema = new ArrayList<>();
        List<Double> positiveExtrema = new ArrayList<>();
        for(int i = 0; i < indexes.size() - 1; ++ i) {
            Double a = values.get(indexes.get(i)).value;
            Double b = values.get(indexes.get(i+1)).value;
            if(a > b) {
                positiveExtrema.add(a);
            } else if (a < b) {
                negativeExtrema.add(a);
            }
        }
        Double positiveAverage = calculateAverage(positiveExtrema);
        Double negativeAverage = calculateAverage(negativeExtrema);
        return new ExtremaStats(positiveAverage, negativeAverage,
                calculateStandardDeviation(positiveExtrema, positiveAverage),
                calculateStandardDeviation(negativeExtrema, negativeAverage),
                positiveExtrema.size(), negativeExtrema.size());
    }
}
