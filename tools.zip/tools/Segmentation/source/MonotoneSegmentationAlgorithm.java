package com.test;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import java.util.TreeMap;

import com.test.Structs.*;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

import au.com.bytecode.opencsv.CSVParser;
import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

public class MonotoneSegmentationAlgorithm {

    public static void main(String[] args) {

        String csvPath = null;
        int tolerance = 0; //default
        double seconds = 60; //default
        String dtwPath = null;

        //parse args
        CommandLineParser parser = new DefaultParser();
        Options options = generateOptions();
        CommandLine parsedArgs;
        //show usage
        HelpFormatter formatter = new HelpFormatter();

        try {
            // parse the command line arguments
            parsedArgs = parser.parse( options, args );

            if( parsedArgs.hasOption( "csv" ) ) {
                csvPath = parsedArgs.getOptionValue( "csv" ) ;
            }
            if( parsedArgs.hasOption( "tolerance" ) ) {
                try {
                    tolerance = Integer.parseInt(parsedArgs.getOptionValue( "tolerance" )) ;
                } catch( NumberFormatException exp ) {
                    System.out.println( "Error : tolerance argument is not a number" );
                    formatter.printHelp( "java -jar Segmentation.jar", options );
                    return;
                }
            }
            if( parsedArgs.hasOption( "segment-length" ) ) {
                try {
                    seconds = Double.parseDouble(parsedArgs.getOptionValue("segment-length"));
                } catch( NumberFormatException exp ) {
                    System.out.println( "Error : segment-length argument is not a number" );
                    formatter.printHelp( "java -jar Segmentation.jar", options );
                    return;
                }
            }

            if( parsedArgs.hasOption( "dtw" ) ) {
                dtwPath = parsedArgs.getOptionValue( "dtw" ) ;
            }
        }
        catch( ParseException exp ) {
            System.out.println( "Error : Missing mandatory arguments" );
            formatter.printHelp( "java -jar Segmentation.jar", options );
            return;
        }

        //monotone
        List<SegmentationAlgorithmReturnData> dataset = executeAlgorithm(csvPath, tolerance, seconds, options, formatter);
        if (dataset == null) return;

        //dtw
        if (parsedArgs.hasOption( "dtw" )) {
            DTW.dtw(dtwPath, dataset, options, formatter);
        }
    }

    private static List<SegmentationAlgorithmReturnData> executeAlgorithm(String csvPath, int tolerance, double seconds, Options options, HelpFormatter formatter) {
        //read csv
        List<List<TimestampedDouble>> data;
        try {
            data = readCSV(csvPath, seconds);
        } catch (IOException e) {
            System.out.println(e.getMessage());
            formatter.printHelp( "java -jar Segmentation.jar", options );
            return null;
        }

        //compute data
        List<SegmentationAlgorithmReturnData> dataset = new ArrayList<>();
        for (List<TimestampedDouble> segment : data) {
            dataset.add(computeData(segment, tolerance));
        }
        //write results
        writeCSV(dataset);
        return dataset;
    }

    private static List<List<TimestampedDouble>> readCSV(String csvPath, double seconds) throws IOException {
        List<List<TimestampedDouble>> data = new ArrayList<>();
        CSVReader reader = new CSVReader(new FileReader(csvPath), ',', CSVParser.DEFAULT_QUOTE_CHARACTER, 18);
        double cutoff = seconds;
        String[] line = null;
        List<TimestampedDouble> segment = new ArrayList<>();

        while((line = reader.readNext())!= null){
            double time = Double.parseDouble(line[0]);
            double value = Double.parseDouble(line[23]);
            if (time > cutoff) {
                cutoff = time + seconds;
                data.add(segment);
                segment = new ArrayList<>();
                segment.add(new TimestampedDouble(time, value));
            } else {
                segment.add(new TimestampedDouble(time, value));
            }
        }
        //add remaining
        data.add(segment);
        return data;
    }

    private static Options generateOptions() {
        Options options = new Options();
        options.addOption( OptionBuilder.withLongOpt( "csv" )
                .withDescription( "[mandatory] the path to the csv file with the values to process" )
                .isRequired()
                .hasArg()
                .withArgName("PATH")
                .create() );
        options.addOption( OptionBuilder.withLongOpt( "tolerance" )
                .isRequired()
                .withDescription( "[mandatory] tolerance for the Monotone Segmentation algorithm" )
                .hasArg()
                .withArgName("VALUE")
                .create() );
        options.addOption( OptionBuilder.withLongOpt( "segment-length" )
                .withDescription( "[optional] divide data into SECONDS-long segments : default is 60 seconds" )
                .hasArg()
                .withArgName("SECONDS")
                .create() );
        options.addOption( OptionBuilder.withLongOpt( "dtw" )
                .withDescription( "[optional] the path to the csv file with dtw segment" )
                .hasArg()
                .withArgName("PATH")
                .create() );
        return options;
    }

    private static void writeCSV(List<SegmentationAlgorithmReturnData> dataset) {
        CSVWriter valuesWriter = null;
        CSVWriter statsWriter = null;
        try {
            //files
            valuesWriter = new CSVWriter(new FileWriter("MonotoneSegmentationValues.csv"));
            statsWriter = new CSVWriter(new FileWriter("MonotoneSegmentationStats.csv"));

            //headers
            valuesWriter.writeNext("Segment", "Numéro", "Temps", "Vitesse");
            statsWriter.writeNext("Segment", "Moyenne peaks positifs", "Ecart-type peaks positifs", "Nombre peaks positifs", "Moyenne peaks negatifs", "Ecart-type peaks negatifs", "Nombre peaks negatifs");

            int i = 1;
            for(SegmentationAlgorithmReturnData segment : dataset) {

                int j = 1;
                for (TimestampedDouble d : segment.monotoneValues) {
                    valuesWriter.writeNext( "" + i, "" + j, d.timestamp.toString(), d.value.toString());
                    j++;
                }

                statsWriter.writeNext("" + i, "" + segment.extremaStats.positiveAverage, "" + segment.extremaStats.positiveStandardDeviation, "" + segment.extremaStats.positiveCount,
                        "" + segment.extremaStats.negativeAverage, "" + segment.extremaStats.negativeStandardDeviation, "" + segment.extremaStats.negativeCount);
                i++;
            }
            valuesWriter.close();
            statsWriter.close();
            System.out.println( "Finished Monotone Segmentation" );
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }




    /*********************
     * Algorithm methods *
     *********************/


    private static SegmentationAlgorithmReturnData computeData(List<TimestampedDouble> values, int tolerance) {
        List<Integer> significantExtrema = selectSignificantExtrema(values, tolerance);
        return new SegmentationAlgorithmReturnData(Statistics.computeExtremaStats(values, significantExtrema), piecewiseMonotone(values, significantExtrema));
    }

    private static Map<Integer,Double> computeScaleLabels(List<TimestampedDouble> values) {
        if(values.size() < 3) return new HashMap<>();
        boolean isMin;
        Map<Integer,Double> extrema = new LinkedHashMap<>(values.size());
        Map<Integer,Double> scaleLabels = new HashMap<>(values.size());
        List<Integer> indexes = new ArrayList<>();
        int lastKey = 0;

        //select extrema
        extrema.put(0, values.get(0).value);
        for(int i = 1; i < values.size() - 1; i++) {
            if(values.get(i).value.equals(values.get(i-1).value)) {
                //do nothing
            } else if((values.get(i).value >= values.get(i-1).value) && (values.get(i).value >= values.get(i+1).value)) {
                extrema.put(i, values.get(i).value);
                lastKey= i;
            } else if((values.get(i).value <= values.get(i-1).value) && (values.get(i).value <= values.get(i+1).value)) {
                extrema.put(i, values.get(i).value);
                lastKey= i;
            }
        }
        if(values.get(values.size()-1).value.equals(extrema.get(lastKey))) {
            extrema.remove(lastKey);
            extrema.put(lastKey, values.get(values.size()-1).value);
        } else {
            extrema.put(lastKey + 1, values.get(values.size()-1).value);
        }

        //create scalelabel array
        Collection<Double> tempValues = extrema.values();
        if (tempValues.size() < 2) return new HashMap<>();
        Iterator it = tempValues.iterator();
        Double first = (Double)it.next();
        Double second = (Double)it.next();
        isMin = (first < second);
        for(Map.Entry<Integer,Double> extremum : extrema.entrySet()) {
            int i = extremum.getKey();
            while((indexes.size() > 2) && (( (!isMin) && (extrema.get(i) > extrema.get(indexes.get(1)))) || (isMin && (extrema.get(i) < extrema.get(indexes.get(1))))) ) {
                Double scale = Math.abs(extrema.get(indexes.get(1)) - extrema.get(indexes.get(0)));
                scaleLabels.put(indexes.get(0), scale);
                scaleLabels.put(indexes.get(1), scale);
                indexes.remove(1);
                indexes.remove(0);
            }
            if((indexes.size() == 2) && (( (!isMin) && (extrema.get(i) > extrema.get(indexes.get(1)))) || (isMin && (extrema.get(i) < extrema.get(indexes.get(1))))) ) {
                Double scale = Math.abs(extrema.get(indexes.get(1)) - extrema.get(indexes.get(0)));
                scaleLabels.put(indexes.get(1), scale);
                indexes.remove(1);
            }
            isMin = !isMin;
            indexes.add(0, i);
        }
        while(indexes.size() > 2) {
            Double scale = Math.abs(extrema.get(indexes.get(1)) - extrema.get(indexes.get(0)));
            scaleLabels.put(indexes.get(0), scale);
            indexes.remove(0);
        }
        Double scale = Math.abs(extrema.get(indexes.get(1)) - extrema.get(indexes.get(0)));
        scaleLabels.put(indexes.get(0), scale);
        scaleLabels.put(indexes.get(1), scale);
        indexes.clear();
        return scaleLabels;
    }

    private static List<Integer> selectSignificantExtrema(List<TimestampedDouble> values, int tolerance) {
        Map<Integer,Double> scaleLabels = computeScaleLabels(values);
        List<Integer> significantExtremaIndexes = new ArrayList<>();

        for(Map.Entry<Integer,Double> scaleLabel : scaleLabels.entrySet()) {
            if(scaleLabel.getValue() >= tolerance) {
                significantExtremaIndexes.add(scaleLabel.getKey());
            }
        }
        Collections.sort(significantExtremaIndexes);
        return significantExtremaIndexes;
    }

    private static List<TimestampedDouble> piecewiseMonotone(List<TimestampedDouble> values, List<Integer> indexes){
        Map<Integer,TimestampedDouble> monotoneValues = new TreeMap<>();
        for(int i = 0; i < indexes.size() - 1; ++ i) {
            Double a = values.get(indexes.get(i)).value;
            Double b = values.get(indexes.get(i+1)).value;
            Map<Integer,TimestampedDouble> Xmin = new HashMap<>();
            Map<Integer,TimestampedDouble> Xmax = new HashMap<>();

            if(a > b) {
                Xmin.put(indexes.get(i), values.get(indexes.get(i)));
                Xmax.put(indexes.get(i+1), values.get(indexes.get(i+1)));
                for(int j = indexes.get(i) + 1; j <= indexes.get(i+1); ++j) {
                    if( values.get(j).value < Xmin.get(j-1).value) {
                        Xmin.put(j, values.get(j));
                    } else {
                        Xmin.put(j, Xmin.get(j-1));
                    }
                }
                for(int j = indexes.get(i+1) - 1; j >= indexes.get(i); --j) {
                    if( values.get(j).value < Xmax.get(j+1).value) {
                        Xmax.put(j, Xmax.get(j+1));
                    } else {
                        Xmax.put(j, values.get(j));
                    }
                }
            } else {
                Xmin.put(indexes.get(i+1), values.get(indexes.get(i+1)));
                Xmax.put(indexes.get(i), values.get(indexes.get(i)));
                for(int j = indexes.get(i) + 1; j <= indexes.get(i+1); ++j) {
                    if( values.get(j).value > Xmax.get(j-1).value) {
                        Xmax.put(j, values.get(j));
                    } else {
                        Xmax.put(j, Xmax.get(j-1));
                    }
                }
                for(int j = indexes.get(i+1) - 1; j >= indexes.get(i); --j) {
                    if( values.get(j).value > Xmin.get(j+1).value) {
                        Xmin.put(j, Xmin.get(j+1));
                    } else {
                        Xmin.put(j, values.get(j));
                    }
                }
            }
            for (Map.Entry<Integer,TimestampedDouble> max : Xmax.entrySet()) {
                int key = max.getKey();
                monotoneValues.put(key, new TimestampedDouble(Xmax.get(key).timestamp, (Xmax.get(key).value + Xmin.get(key).value) / 2.0));
            }
        }

        return new ArrayList<>(monotoneValues.values());
    }
}

