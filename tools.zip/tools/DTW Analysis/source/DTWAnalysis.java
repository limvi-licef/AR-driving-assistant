package com.analysis;

import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import au.com.bytecode.opencsv.CSVWriter;

public class DTWAnalysis {

    public static void main(String[] args) {

        CommandLineParser parser = new DefaultParser();
        Options options = generateOptions();
        CommandLine parsedArgs;
        //show usage
        HelpFormatter formatter = new HelpFormatter();

        String jsonPath = "";
        String sensorType = "";
        String user = "";

        try {
            // parse the command line arguments
            parsedArgs = parser.parse( options, args );

            if( parsedArgs.hasOption( "json" ) ) {
                jsonPath = parsedArgs.getOptionValue( "json" ) ;
            }

            if( parsedArgs.hasOption( "sensor" ) ) {
                sensorType = parsedArgs.getOptionValue( "sensor" ) ;
                if(!sensorType.equals("Speed") && !sensorType.equals("Acceleration") && !sensorType.equals("Rotation")) {
                    throw new ParseException("Invalid argument");
                }
            }

            if( parsedArgs.hasOption( "user" ) ) {
                user = parsedArgs.getOptionValue( "user" ) ;
            }
        }
        catch( ParseException exp ) {
            System.out.println( "Error : Missing or invalid argument" );
            formatter.printHelp( "java -jar DTW_Analysis.jar", options );
            return;
        }

        JSONParser jsonParser = new JSONParser();
        JSONObject json;
        try {
            Object obj = jsonParser.parse(new FileReader(jsonPath));
            json = (JSONObject) obj;
        } catch (IOException | org.json.simple.parser.ParseException e) {
            System.out.println( "Error : Could Not Read File" );
            formatter.printHelp( "java -jar DTW_analysis.jar", options );
            return;
        }

        List<Event> trainingEvents = getEvents(json);

        if(sensorType.equals("Speed")) {
            List<DTWResult> resultsDTW = getSpeedResults(json, user);
            List<Datapoint> data = getSpeedData(json);
            writeSpeedCSV(trainingEvents, resultsDTW, data, user);
        }

        if(sensorType.equals("Rotation")) {
            List<DTWResult> resultsDTW = getRotationResults(json, user);
            List<Datapoint> data = getRotationData(json);
            writeRotationCSV(trainingEvents, resultsDTW, data, user);
        }

        if(sensorType.equals("Acceleration")) {
            List<DTWResult> resultsDTW = getAccelerationResults(json, user);
            List<AccelerationDatapoint> data = getAccelerationData(json);
            writeAccelerationCSV(trainingEvents, resultsDTW, data, user);
        }

        System.out.println("Done");
    }

    private static void writeSpeedCSV(List<Event> eventset, List<DTWResult> resultset, List<Datapoint> dataset, String user) {
        CSVWriter eventsWriter = null;
        CSVWriter resultsWriter = null;
        CSVWriter dataWriter = null;
        try {
            //files
            eventsWriter = new CSVWriter(new FileWriter("Speed Training Events.csv"));
            resultsWriter = new CSVWriter(new FileWriter("Speed DTW Results.csv"));
            dataWriter = new CSVWriter(new FileWriter("Speed Data.csv"));

            //headers
            eventsWriter.writeNext("Event Label", "Event Duration", "Timestamp", "Speed");
            resultsWriter.writeNext("Event Label", "Distance", "Segment Start", "Segment Stop");
            dataWriter.writeNext("Timestamp", "Speed");

            for(Datapoint d : dataset) {
                if(!user.isEmpty() && !user.equals(d.user)) {
                    continue;
                }
                dataWriter.writeNext("" + d.timestamp, "" + d.value);
            }

            for(DTWResult r : resultset) {
                resultsWriter.writeNext(r.eventLabel, "" + r.distance, "" + r.segmentStart, "" + r.segmentStop);
            }

            for(Event e : eventset) {
                for(Datapoint d : dataset) {
                    if (d.timestamp >= e.start && d.timestamp <= e.end) {
                        eventsWriter.writeNext(e.label, "" + e.duration, "" + d.timestamp, "" + d.value);
                    }
                }
            }

            eventsWriter.close();
            resultsWriter.close();
            dataWriter.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void writeRotationCSV(List<Event> eventset, List<DTWResult> resultset, List<Datapoint> dataset, String user) {
        CSVWriter eventsWriter = null;
        CSVWriter resultsWriter = null;
        CSVWriter dataWriter = null;
        try {
            //files
            eventsWriter = new CSVWriter(new FileWriter("Rotation Training Events.csv"));
            resultsWriter = new CSVWriter(new FileWriter("Rotation DTW Results.csv"));
            dataWriter = new CSVWriter(new FileWriter("Rotation Data.csv"));

            //headers
            eventsWriter.writeNext("Event Label", "Event Duration", "Timestamp", "Azimuth");
            resultsWriter.writeNext("Event Label", "Distance", "Segment Start", "Segment Stop");
            dataWriter.writeNext("Timestamp", "Azimuth");

            for(Datapoint d : dataset) {
                if(!user.isEmpty() && !user.equals(d.user)) {
                    continue;
                }
                dataWriter.writeNext("" + d.timestamp, "" + d.value);
            }

            for(DTWResult r : resultset) {
                resultsWriter.writeNext(r.eventLabel, "" + r.distance, "" + r.segmentStart, "" + r.segmentStop);
            }

            for(Event e : eventset) {
                for(Datapoint d : dataset) {
                    if (d.timestamp >= e.start && d.timestamp <= e.end) {
                        eventsWriter.writeNext(e.label, "" + e.duration, "" + d.timestamp, "" + d.value);
                    }
                }
            }

            eventsWriter.close();
            resultsWriter.close();
            dataWriter.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void writeAccelerationCSV(List<Event> eventset, List<DTWResult> resultset, List<AccelerationDatapoint> dataset, String user) {
        CSVWriter eventsWriter = null;
        CSVWriter resultsWriter = null;
        CSVWriter dataWriter = null;
        try {
            //files
            eventsWriter = new CSVWriter(new FileWriter("Acceleration Training Events.csv"));
            resultsWriter = new CSVWriter(new FileWriter("Acceleration DTW Results.csv"));
            dataWriter = new CSVWriter(new FileWriter("Acceleration Data.csv"));

            //headers
            eventsWriter.writeNext("Event Label", "Event Duration", "Timestamp", "AxisX", "AxisY", "AxisZ");
            resultsWriter.writeNext("Event Label", "Distance", "Segment Start", "Segment Stop");
            dataWriter.writeNext("Timestamp", "AxisX", "AxisY", "AxisZ");

            for(AccelerationDatapoint d : dataset) {
                if(!user.isEmpty() && !user.equals(d.user)) {
                    continue;
                }
                dataWriter.writeNext("" + d.timestamp, d.x, d.y, d.z);
            }

            for(DTWResult r : resultset) {
                resultsWriter.writeNext(r.eventLabel, "" + r.distance, "" + r.segmentStart, "" + r.segmentStop);
            }

            for(Event e : eventset) {
                for(AccelerationDatapoint d : dataset) {
                    if (d.timestamp >= e.start && d.timestamp <= e.end) {
                        eventsWriter.writeNext(e.label, "" + e.duration, "" + d.timestamp, d.x, d.y, d.z);
                    }
                }
            }

            eventsWriter.close();
            resultsWriter.close();
            dataWriter.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    private static List<Event> getEvents(JSONObject json) {
        JSONArray trainingEvents = (JSONArray) json.get("TrainingEvents");
        List<Event> list = new ArrayList<>();
        for(Object o : trainingEvents){
            if ( o instanceof JSONObject ) {
                JSONObject obj = (JSONObject)o;
                list.add(new Event((String)obj.get("Label"), Long.parseLong((String)obj.get("Duration")), Long.parseLong((String)obj.get("StartTimestamp")), Long.parseLong((String)obj.get("EndTimestamp"))));
            }
        }
        return list;
    }

    private static List<DTWResult> getSpeedResults(JSONObject json, String user) {
        JSONArray resultsDTW = (JSONArray) json.get("ResultsDTW");
        List<DTWResult> list = new ArrayList<>();
        for(Object o : resultsDTW){
            if ( o instanceof JSONObject ) {
                JSONObject obj = (JSONObject)o;
                String str = (String)obj.get("DistanceSpeed");
                String userID = (String)obj.get("CurrentUserID");
                if(!user.isEmpty() && !user.equals(userID)) {
                    continue;
                }
                if(!str.isEmpty()) {
                    list.add(new DTWResult((String) obj.get("EventLabel"), Double.parseDouble((String) obj.get("DistanceSpeed")), Long.parseLong((String) obj.get("SegmentStart")), Long.parseLong((String) obj.get("SegmentStop"))));
                }
            }
        }
        return list;
    }

    private static List<Datapoint> getSpeedData(JSONObject json) {
        JSONArray speedData = (JSONArray) json.get("SpeedData");
        List<Datapoint> list = new ArrayList<>();
        for(Object o : speedData){
            if ( o instanceof JSONObject ) {
                JSONObject obj = (JSONObject)o;
                list.add(new Datapoint((String)obj.get("CurrentUserID"), Long.parseLong((String)obj.get("Timestamp")), Double.parseDouble((String)obj.get("Speed"))));
            }
        }
        return list;
    }

    private static List<DTWResult> getRotationResults(JSONObject json, String user) {
        JSONArray resultsDTW = (JSONArray) json.get("ResultsDTW");
        List<DTWResult> list = new ArrayList<>();
        for(Object o : resultsDTW){
            if ( o instanceof JSONObject ) {
                JSONObject obj = (JSONObject)o;
                String userID = (String)obj.get("CurrentUserID");
                if(!user.isEmpty() && !user.equals(userID)) {
                    continue;
                }
                String str = (String)obj.get("DistanceRotation");
                if(!str.isEmpty()) {
                    list.add(new DTWResult((String)obj.get("EventLabel"),Double.parseDouble((String)obj.get("DistanceRotation")), Long.parseLong((String)obj.get("SegmentStart")), Long.parseLong((String)obj.get("SegmentStop"))));
                }
            }
        }
        return list;
    }

    private static List<Datapoint> getRotationData(JSONObject json) {
        JSONArray data = (JSONArray) json.get("RotationData");
        List<Datapoint> list = new ArrayList<>();
        for(Object o : data){
            if ( o instanceof JSONObject ) {
                JSONObject obj = (JSONObject)o;
                list.add(new Datapoint((String)obj.get("CurrentUserID"), Long.parseLong((String)obj.get("Timestamp")), Double.parseDouble((String)obj.get("Azimuth"))));
            }
        }
        return list;
    }

    private static List<DTWResult> getAccelerationResults(JSONObject json, String user) {
        JSONArray resultsDTW = (JSONArray) json.get("ResultsDTW");
        List<DTWResult> list = new ArrayList<>();
        for(Object o : resultsDTW){
            if ( o instanceof JSONObject ) {
                JSONObject obj = (JSONObject)o;
                String userID = (String)obj.get("CurrentUserID");
                if(!user.isEmpty() && !user.equals(userID)) {
                    continue;
                }
                String str = (String)obj.get("DistanceAcceleration");
                if(!str.isEmpty()) {
                    list.add(new DTWResult((String)obj.get("EventLabel"), Double.parseDouble((String)obj.get("DistanceAcceleration")), Long.parseLong((String)obj.get("SegmentStart")), Long.parseLong((String)obj.get("SegmentStop"))));
                }
            }
        }
        return list;
    }

    private static List<AccelerationDatapoint> getAccelerationData(JSONObject json) {
        JSONArray data = (JSONArray) json.get("LinearAccelerometerData");
        List<AccelerationDatapoint> list = new ArrayList<>();
        for(Object o : data){
            if ( o instanceof JSONObject ) {
                JSONObject obj = (JSONObject)o;
                list.add(new AccelerationDatapoint((String)obj.get("CurrentUserID"), Long.parseLong((String)obj.get("Timestamp")), (String)obj.get("AxisX"), (String)obj.get("AxisY"), (String)obj.get("AxisZ")));
            }
        }
        return list;
    }

    private static Options generateOptions() {
        Options options = new Options();
        options.addOption( OptionBuilder.withLongOpt( "json" )
                .withDescription( "[mandatory] the path to json database file" )
                .isRequired()
                .hasArg()
                .withArgName("PATH")
                .create() );
        options.addOption( OptionBuilder.withLongOpt( "sensor" )
                .withDescription( "[mandatory] the sensor type to extract : Speed, Acceleration, Rotation" )
                .isRequired()
                .hasArg()
                .withArgName("TYPE")
                .create() );
        options.addOption( OptionBuilder.withLongOpt( "user" )
                .withDescription( "[optional] extract only data associated with user, if specified" )
                .hasArg()
                .withArgName("ID")
                .create() );
        return options;
    }

    private static class Event {
        String label;
        long duration;
        long start;
        long end;

        public Event(String label, long duration, long start, long end) {
            this.label = label;
            this.duration = duration;
            this.start = start;
            this.end = end;
        }
    }

    private static class DTWResult {
        String eventLabel;
        double distance;
        long segmentStart;
        long segmentStop;

        public DTWResult(String eventLabel, double distance, long segmentStart, long segmentStop) {
            this.eventLabel = eventLabel;
            this.distance = distance;
            this.segmentStart = segmentStart;
            this.segmentStop = segmentStop;
        }
    }

    private static class Datapoint {
        String user;
        long timestamp;
        double value;

        public Datapoint(String user, long timestamp, double value) {
            this.user = user;
            this.timestamp = timestamp;
            this.value = value;
        }
    }

    private static class AccelerationDatapoint {
        String user;
        long timestamp;
        String x;
        String y;
        String z;

        public AccelerationDatapoint(String user, long timestamp, String x, String y, String z) {
            this.user = user;
            this.timestamp = timestamp;
            this.x = x;
            this.y = y;
            this.z = z;
        }
    }

}
